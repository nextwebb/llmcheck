# LLMCheck article companion

Python 3.10+, Git and PyYAML required. Use LLMCheck source commit 6d101ae90781b8dc06965f57313445f8878cf6d6 from https://github.com/nextwebb/llmcheck.

```sh
python companion/offline_demo.py --repo /path/to/llmcheck --output /path/to/new-output
python companion/smoke_test.py --repo /path/to/llmcheck
python companion/inspect_results.py /path/to/new-output/replay-results.json
LLMCHECK_REPO=/path/to/llmcheck python evidence/twelve-cases/run.py
LLMCHECK_REPO=/path/to/llmcheck python evidence/gate-probes/run.py
```

All responses and policies are synthetic fixtures. No API key or live calls are required. The injected literal judge is not a benchmark of the default semantic judge. The companion refuses output overwrite; experiment scripts write beside themselves. Expected replay verdicts: FAIL, PASS, FAIL, FAIL. Twelve selected cases yield four agreements and eight disagreements.
